<?php

interface IEnviarEmail
{
    public function enviarEmail();
}