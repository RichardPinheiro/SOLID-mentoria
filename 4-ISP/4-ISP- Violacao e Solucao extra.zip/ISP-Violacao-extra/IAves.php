<?php
interface IAves
{
    public function andar();
    public function voar();
    public function nadar();
}