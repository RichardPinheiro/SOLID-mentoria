<?php

class Andorinha implements IAves
{
    public function voar()
    {
        //lógica
    }

    public function nadar()
    {
        //Andorinha não nada, esse método não serve!
    }

    public function andar()
    {
        //lógica
    }
}