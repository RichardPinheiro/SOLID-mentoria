<?php

class Pinguim implements IAves
{
    public function voar()
    {
        //Pinguim não voa, esse método não serve!
    }

    public function nadar()
    {
        //lógica
    }

    public function andar()
    {
        //lógica
    }
}