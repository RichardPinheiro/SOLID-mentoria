<?php

class Andorinha implements IAvesQueAndam, IAvesQueVoam
{
    public function voar()
    {
        //lógica
    }

    public function andar()
    {
        //lógica
    }
}