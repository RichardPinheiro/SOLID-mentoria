<?php

class Pato implements IAvesQueAndam, IAvesQueVoam, IAvesQueNadam
{
    public function voar()
    {
        //lógica
    }

    public function nadar()
    {
        //lógica
    }

    public function andar()
    {
        //lógica
    }
}