<?php

class Pinguim implements IAvesQueAndam,  IAvesQueNadam
{
    public function nadar()
    {
        //lógica
    }

    public function andar()
    {
        //lógica
    }
}