<?php

interface IAvesQueAndam
{
    public function andar();
}