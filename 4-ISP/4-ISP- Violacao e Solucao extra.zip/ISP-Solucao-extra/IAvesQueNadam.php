<?php

interface IAvesQueNadam
{
    public function nadar();
}