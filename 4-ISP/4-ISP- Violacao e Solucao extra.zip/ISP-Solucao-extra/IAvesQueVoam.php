<?php

interface IAvesQueVoam
{
    public function voar();
}