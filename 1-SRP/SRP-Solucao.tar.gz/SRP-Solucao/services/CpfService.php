<?php

class CpfService
{
    /**
     * Cpf validation
     *
     * @param [String] $cpf
     * @return Bolean
     */
    static public function cpfValidation($cpf)
    {
        if (strlen($cpf) != 11) {
            return false;
        }

        return true;
    }
}